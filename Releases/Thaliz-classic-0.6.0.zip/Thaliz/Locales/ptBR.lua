local L = LibStub("AceLocale-3.0"):NewLocale("Thaliz", "ptBR")
if not L then return end

-- Resurrection spell name
L["Ancestral Spirit"] = "Espírito Ancestral"
L["Rebirth"] = "Renascimento"
L["Redemption"] = "Redenção"
L["Resurrection"] = "Ressurreição"
