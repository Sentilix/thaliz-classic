local L = LibStub("AceLocale-3.0"):NewLocale("Thaliz", "deDE")
if not L then return end

-- Resurrection spell name
L["Ancestral Spirit"] = "Geist der Ahnen"
L["Rebirth"] = "Wiedergeburt"
L["Redemption"] = "Erlösung"
L["Resurrection"] = "Auferstehung"
