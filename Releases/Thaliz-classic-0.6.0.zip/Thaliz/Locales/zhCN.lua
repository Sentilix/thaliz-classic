local L = LibStub("AceLocale-3.0"):NewLocale("Thaliz", "zhCN")
if not L then return end

-- Resurrection spell name
L["Ancestral Spirit"] = "先祖之魂"
L["Rebirth"] = "复生"
L["Redemption"] = "救赎"
L["Resurrection"] = "复活术"
