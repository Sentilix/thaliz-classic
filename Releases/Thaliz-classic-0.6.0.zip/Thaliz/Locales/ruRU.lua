local L = LibStub("AceLocale-3.0"):NewLocale("Thaliz", "ruRU")
if not L then return end

-- Resurrection spell name
L["Ancestral Spirit"] = "Дух предков"
L["Rebirth"] = "Возрождение"
L["Redemption"] = "Искупление"
L["Resurrection"] = "Воскрешение"
