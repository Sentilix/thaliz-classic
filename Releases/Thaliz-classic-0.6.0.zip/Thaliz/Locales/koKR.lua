local L = LibStub("AceLocale-3.0"):NewLocale("Thaliz", "koKR")
if not L then return end

-- Resurrection spell name
L["Ancestral Spirit"] = "고대의 영혼"
L["Rebirth"] = "환생"
L["Redemption"] = "구원"
L["Resurrection"] = "부활"
