local L = LibStub("AceLocale-3.0"):NewLocale("Thaliz", "esES")
if not L then return end

-- Resurrection spell name
L["Ancestral Spirit"] = "Espíritu ancestral"
L["Rebirth"] = "Renacer"
L["Redemption"] = "Redención"
L["Resurrection"] = "Resurrección"
